alembic upgrade head
python main.py
